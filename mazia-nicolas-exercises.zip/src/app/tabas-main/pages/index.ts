export * from './form-page/form-page.component';
export * from './init-page/init-page.component';
export * from './tests-page/tests-page.component';