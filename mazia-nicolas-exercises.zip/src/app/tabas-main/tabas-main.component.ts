import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tabas-main',
  templateUrl: './tabas-main.component.html',
  styleUrls: ['./tabas-main.component.scss']
})
export class TabasMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
