import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { TabasMainModule } from './tabas-main/tabas-main.module';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    TabasMainModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
